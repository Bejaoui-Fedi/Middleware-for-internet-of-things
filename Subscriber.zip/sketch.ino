
#include <WiFi.h>
#include <PubSubClient.h>

// WiFi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// MQTT
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;
const char* topic = "serre/fedi/obstacle/2026";

// Buzzer
#define BUZZER 23

WiFiClient espClient;
PubSubClient client(espClient);

bool buzzerActif = false;

// Reception MQTT
void callback(char* topic, byte* payload,
              unsigned int length) {

  String message = "";

  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  Serial.print("Message recu : ");
  Serial.println(message);

  if (message == "CLEAR") {

    if (buzzerActif) {
      noTone(BUZZER);
      buzzerActif = false;

      Serial.println("Obstacle eloigne !");
      Serial.println("BUZZER OFF");
    }

  } else {

    float distance = message.toFloat();

    if (distance > 0 && distance < 100) {

      if (!buzzerActif) {
        tone(BUZZER, 2000);
        buzzerActif = true;

        Serial.println("!!! ALERTE OBSTACLE !!!");
        Serial.println("BUZZER ON");
      }

      Serial.print("Distance dangereuse : ");
      Serial.print(distance);
      Serial.println(" cm");
    }
  }
}

// Connexion MQTT
void reconnect() {
  while (!client.connected()) {

    Serial.print("Connexion MQTT...");

    if (client.connect("Subscriber_Fedi_02")) {

      Serial.println("Connecte !");

      client.subscribe(topic);

      Serial.println("Abonnement MQTT reussi !");

    } else {

      Serial.print("Echec : ");
      Serial.println(client.state());

      delay(1000);
    }
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(BUZZER, OUTPUT);
  noTone(BUZZER);

  WiFi.begin(ssid, password);

  Serial.print("Connexion WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }

  Serial.println("\nWiFi connecte !");

  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);

  client.setKeepAlive(30);
  client.setSocketTimeout(2);
}

void loop() {

  if (!client.connected()) {
    reconnect();
  }

  client.loop();
}
