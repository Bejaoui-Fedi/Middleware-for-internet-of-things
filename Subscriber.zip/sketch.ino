
#include <WiFi.h>
#include <PubSubClient.h>

// WiFi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// MQTT
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;
const char* topic = "fedi/scenario3/valeur";

// Buzzer
#define BUZZER_PIN 5

// Seuil
#define SEUIL 250

WiFiClient espClient;
PubSubClient client(espClient);

// Reception MQTT
void callback(char* topic, byte* payload, unsigned int length) {

  char message[20];

  if (length >= sizeof(message)) {
    return;
  }

  memcpy(message, payload, length);
  message[length] = '\0';

  int valeur = atoi(message);

  Serial.print("Valeur recue : ");
  Serial.println(valeur);

  // Test du seuil
  if (valeur > SEUIL) {

    Serial.println("!!! ALERTE : SEUIL DEPASSE !!!");

    tone(BUZZER_PIN, 1000);

  } else {

    Serial.println("Valeur normale");

    noTone(BUZZER_PIN);
  }
}

void reconnect() {

  while (!client.connected()) {

    Serial.print("Connexion MQTT...");

    if (client.connect("ESP32_Subscriber_Scenario3")) {

      Serial.println("Connecte !");

      client.subscribe(topic);

      Serial.println("Abonnement reussi !");

    } else {

      Serial.println("Echec !");
      delay(2000);
    }
  }
}

void setup() {

  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);

  // Connexion WiFi
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connecte !");

  // Configuration MQTT
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

void loop() {

  if (!client.connected()) {
    reconnect();
  }

  client.loop();
}
