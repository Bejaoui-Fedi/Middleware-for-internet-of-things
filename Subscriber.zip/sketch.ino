
#include <WiFi.h>
#include <PubSubClient.h>

// WiFi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// MQTT
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;
const char* topic = "fedi/scenario2/alerte";

// Buzzer
const int BUZZER_PIN = 5;

// Communication
WiFiClient espClient;
PubSubClient client(espClient);

// Fonction de reception MQTT
void callback(char* topic, byte* payload, unsigned int length) {

  String message = "";

  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  Serial.print("Valeur recue : ");
  Serial.println(message);

  if (message == "1") {

    Serial.println("!!! ALERTE : TEMPERATURE ELEVEE !!!");

    tone(BUZZER_PIN, 1000);

  } else if (message == "0") {

    Serial.println("Temperature normale");

    noTone(BUZZER_PIN);
  }
}

void reconnect() {

  while (!client.connected()) {

    Serial.print("Connexion MQTT...");

    if (client.connect("ESP32_Subscriber_Fedi")) {

      Serial.println("Connecte !");

      client.subscribe(topic);

      Serial.println("Abonnement au topic reussi");

    } else {

      Serial.println("Echec !");
      delay(2000);
    }
  }
}

void setup() {

  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);

  // Connexion WiFi
  WiFi.begin(ssid, password);

  Serial.print("Connexion WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connecte !");

  // Configuration MQTT
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

void loop() {

  if (!client.connected()) {
    reconnect();
  }

  client.loop();
}
