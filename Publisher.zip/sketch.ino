
#include <WiFi.h>
#include <PubSubClient.h>

// WiFi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// MQTT
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;
const char* topic = "serre/fedi/obstacle/2026";

// HC-SR04
#define TRIG 5
#define ECHO 18

WiFiClient espClient;
PubSubClient client(espClient);

bool obstacleAvant = false;

unsigned long lastMeasure = 0;
const unsigned long interval = 100;

// Mesurer la distance
float mesurerDistance() {
  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG, LOW);

  long duree = pulseIn(ECHO, HIGH, 30000);

  if (duree == 0) return -1;

  return duree * 0.0343 / 2;
}

// Connexion MQTT
void reconnect() {
  while (!client.connected()) {
    Serial.print("Connexion MQTT...");

    if (client.connect("Publisher_Fedi_01")) {
      Serial.println("Connecte !");
    } else {
      Serial.print("Echec : ");
      Serial.println(client.state());
      delay(1000);
    }
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);

  WiFi.begin(ssid, password);

  Serial.print("Connexion WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }

  Serial.println("\nWiFi connecte !");

  client.setServer(mqtt_server, mqtt_port);
  client.setKeepAlive(30);
  client.setSocketTimeout(2);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  if (millis() - lastMeasure >= interval) {
    lastMeasure = millis();

    float distance = mesurerDistance();

    if (distance > 0) {

      Serial.print("Distance : ");
      Serial.print(distance);
      Serial.println(" cm");

      if (distance < 100) {

        char message[20];
        snprintf(message, sizeof(message), "%.1f", distance);

        client.publish(topic, message);

        if (!obstacleAvant) {
          Serial.println("OBSTACLE DETECTE !");
        }

        obstacleAvant = true;

      } else {

        if (obstacleAvant) {
          client.publish(topic, "CLEAR");

          Serial.println("Obstacle eloigne !");
          obstacleAvant = false;
        }
      }
    }
  }
}
