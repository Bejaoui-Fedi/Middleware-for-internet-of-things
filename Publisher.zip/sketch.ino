
#include <WiFi.h>
#include <PubSubClient.h>

// WiFi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// MQTT
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;
const char* topic = "fedi/scenario3/valeur";

// Potentiometre
#define POT_PIN 34

WiFiClient espClient;
PubSubClient client(espClient);

void setup() {
  Serial.begin(115200);

  // Connexion WiFi
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connecte !");

  // Configuration MQTT
  client.setServer(mqtt_server, mqtt_port);
}

void reconnect() {
  while (!client.connected()) {

    Serial.print("Connexion MQTT...");

    if (client.connect("ESP32_Publisher_Scenario3")) {
      Serial.println("Connecte !");
    } else {
      Serial.println("Echec !");
      delay(2000);
    }
  }
}

void loop() {

  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  // Lecture du potentiometre
  int valeur = analogRead(POT_PIN);

  Serial.print("Valeur potentiometre : ");
  Serial.println(valeur);

  // Publication MQTT
  char message[10];
  sprintf(message, "%d", valeur);

  client.publish(topic, message);

  Serial.println("Valeur publiee !");

  delay(500);
}
