
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

const char* ssid = "Wokwi-GUEST";
const char* password = "";

const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;
const char* topic = "fedi/scenario2/alerte";

#define DHT_PIN 4
#define DHT_TYPE DHT11

DHT dht(DHT_PIN, DHT_TYPE);

WiFiClient espClient;
PubSubClient client(espClient);

void setup() {
  Serial.begin(115200);

  dht.begin();

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connecte !");

  client.setServer(mqtt_server, mqtt_port);
}

void reconnect() {
  while (!client.connected()) {
    if (client.connect("ESP32_Publisher_Fedi")) {
      Serial.println("MQTT connecte !");
    } else {
      Serial.println("Echec MQTT");
      delay(2000);
    }
  }
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  float temperature = dht.readTemperature();

  if (isnan(temperature)) {
    Serial.println("Erreur lecture DHT11 !");
    delay(2000);
    return;
  }

  Serial.print("Temperature : ");
  Serial.print(temperature);
  Serial.println(" C");

  if (temperature > 30) {
    client.publish(topic, "1");
    Serial.println("Alerte publiee : 1");
  } else {
    client.publish(topic, "0");
    Serial.println("Temperature normale : 0");
  }

  delay(2000);
}
